import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AriphmeticTest {
	private static Ariphmetic a;

//	@Before
//	public void before() {
//		a = new Ariphmetic();
//	}
	
	@BeforeClass
	public static void beforeClass() {
		a = new Ariphmetic();
	}
	
	@Test
	public void testAdd() {
		assertEquals(4, a.add(2, 2));
	}

	@Test
	public void testSub() throws Exception {
		assertEquals(3, a.sub(5, 2));
	}

	@Test
	public void testMul() throws Exception {
		assertEquals(3, a.mul(1, 3));
	}

	@Test
	public void testDiv() throws Exception {
		assertEquals(3, a.div(6, 2));
	}

	@Test
	public void testDivByZero() throws Exception {
		assertEquals(5, a.div(5, 0));
	}

}
