
public class Ariphmetic {
	
//	static int add (int a, int b) {
//		return a + b;
//	}
//	
//	static int sub (int a, int b) {
//		return a - b;
//	}
//	
//	static int mul (int a, int b) {
//		return a * b;
//	}
//	
//	static int div (int a, int b) {
//		if (b == 0) 
//			return a;
//		return a / b;
//	}
	
	int add (int a, int b) {
		return a + b;
	}
	
	int sub (int a, int b) {
		return a - b;
	}
	
	int mul (int a, int b) {
		return a * b;
	}
	
	int div (int a, int b) {
		if (b == 0) 
			return a;
		return a / b;
	}
	
}
